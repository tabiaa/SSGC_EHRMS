class Employee {
  final int id;
  final String fullName;
  final String? profilePictureUrl;

  Employee({required this.id, required this.fullName, this.profilePictureUrl});

  factory Employee.fromJson(Map<String, dynamic> json) {
    return Employee(
      id: json['employee_id'],
      fullName: json['full_name'],
      profilePictureUrl: json['profile_picture_url'],
    );
  }
}