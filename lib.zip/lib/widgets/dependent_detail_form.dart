import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import '../models/dependent.dart';
import '../services/api_service.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class DependentDetailForm extends StatefulWidget {
  final Dependent dependent;
  final VoidCallback onUpdated;

  const DependentDetailForm({
    required this.dependent,
    required this.onUpdated,
    Key? key,
  }) : super(key: key);

  @override
  _DependentDetailFormState createState() => _DependentDetailFormState();
}

class _DependentDetailFormState extends State<DependentDetailForm> {
  final _formKey = GlobalKey<FormState>();
  late Map<String, dynamic> _editableFields;
  bool _uploading = false;

  @override
  void initState() {
    super.initState();
    _editableFields = {
      'relationship_type': widget.dependent.relationshipType,
      'name': widget.dependent.name,
      'date_of_birth': widget.dependent.dateOfBirth,
      'medical_elsewhere': widget.dependent.medicalElsewhere,
      'family_no': widget.dependent.familyNo,
      'blood_group': widget.dependent.bloodGroup,
      'cnic': widget.dependent.cnic,
    };
  }

  bool _isEditable(String key) {
    final value = _getFieldValue(key);
    return value == null || value == '';
  }

  dynamic _getFieldValue(String key) {
    switch (key) {
      case 'relationship_type':
        return widget.dependent.relationshipType;
      case 'name':
        return widget.dependent.name;
      case 'date_of_birth':
        return widget.dependent.dateOfBirth;
      case 'medical_elsewhere':
        return widget.dependent.medicalElsewhere;
      case 'family_no':
        return widget.dependent.familyNo;
      case 'blood_group':
        return widget.dependent.bloodGroup;
      case 'cnic':
        return widget.dependent.cnic;
      default:
        return null;
    }
  }

  Future<void> _pickAndUpload(String fieldKey) async {
    final picker = ImagePicker();

    // Choose capture or gallery
    final choice = await showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Wrap(
        children: [
          ListTile(
            leading: Icon(Icons.camera_alt, color: Colors.orange),
            title: Text('Capture from Camera'),
            onTap: () => Navigator.pop(context, ImageSource.camera),
          ),
          ListTile(
            leading: Icon(Icons.image, color: Colors.deepOrange),
            title: Text('Select from Gallery'),
            onTap: () => Navigator.pop(context, ImageSource.gallery),
          ),
        ],
      ),
    );

    if (choice == null) return;

    final XFile? file = await picker.pickImage(source: choice);
    if (file == null) return;

    setState(() => _uploading = true);

    final request = http.MultipartRequest(
      'POST',
      Uri.parse('http://10.145.219.182/api1/upload.php'),
    );

    final multipartFile = await http.MultipartFile.fromPath('file', file.path);
    request.files.add(multipartFile);
    request.fields['dependent_id'] = widget.dependent.id.toString();
    request.fields['field'] = fieldKey;

    try {
      final response = await request.send();
      final respStr = await response.stream.bytesToString();
      final res = jsonDecode(respStr);

      setState(() => _uploading = false);

      if (response.statusCode == 200 && res['success']) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('✅ ${res['message']} (${res['filename'] ?? "File uploaded"})'),
            backgroundColor: Colors.green,
          ),
        );
        widget.onUpdated();
      } else {
        throw Exception(res['message'] ?? 'Upload failed');
      }
    } catch (e) {
      setState(() => _uploading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Upload error: $e')),
      );
    }
  }

  Future<void> _submitForm() async {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    final updates = <String, dynamic>{};
    _editableFields.forEach((key, newValue) {
      final originalValue = _getFieldValue(key);
      if ((originalValue == null || originalValue == '') &&
          (newValue != null && newValue != '')) {
        updates[key] = newValue;
      }
    });

    if (updates.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Nothing to update')),
      );
      return;
    }

    try {
      final res = await ApiService.updateDependent(widget.dependent.id, updates);
      if (res['success']) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Updated successfully')),
        );
        widget.onUpdated();
        Navigator.pop(context);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(res['message'] ?? 'Update failed')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Update failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFFF512F), Color(0xFFF09819)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      widget.dependent.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
                const SizedBox(height: 15),

                // Form Card
                Container(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 25),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.95),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 10,
                        offset: Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        _buildField('Name', 'name', TextInputType.text),
                        _buildField('Relationship', 'relationship_type', TextInputType.text),
                        _buildField('CNIC', 'cnic', TextInputType.text),
                        _buildField('Blood Group', 'blood_group', TextInputType.text),
                        _buildField('Family No', 'family_no', TextInputType.text),
                        _buildDateField(),
                        _buildMedicalSwitch(),
                        const SizedBox(height: 20),

                        _uploading
                            ? const CircularProgressIndicator()
                            : Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _buildUploadButton('Profile Picture', 'profile_picture'),
                            _buildUploadButton('CNIC Front', 'cnic_front'),
                            _buildUploadButton('CNIC Back', 'cnic_back'),
                            _buildUploadButton('B-Form', 'bform'),
                          ],
                        ),

                        const SizedBox(height: 25),
                        SizedBox(
                          width: double.infinity,
                          height: 50,
                          child: ElevatedButton(
                            onPressed: _submitForm,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFFFF512F),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(25),
                              ),
                            ),
                            child: const Text(
                              'Submit Updates',
                              style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildField(String label, String key, TextInputType inputType) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        initialValue: _getFieldValue(key)?.toString(),
        enabled: _isEditable(key),
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        keyboardType: inputType,
        onSaved: (v) => _editableFields[key] = v,
      ),
    );
  }

  Widget _buildDateField() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        enabled: _isEditable('date_of_birth'),
        decoration: InputDecoration(
          labelText: 'Date of Birth (YYYY-MM-DD)',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
        ),
        keyboardType: TextInputType.datetime,
        onSaved: (v) => _editableFields['date_of_birth'] = v,
        validator: (v) {
          if (v != null && v.isNotEmpty) {
            if (!RegExp(r'^\d{4}-\d{2}-\d{2}$').hasMatch(v)) {
              return 'Invalid date format (use YYYY-MM-DD)';
            }
          }
          return null;
        },
      ),
    );
  }

  Widget _buildMedicalSwitch() {
    return SwitchListTile(
      title: const Text('Medical Elsewhere'),
      value: _editableFields['medical_elsewhere'] ?? false,
      onChanged: _isEditable('medical_elsewhere')
          ? (bool? value) =>
          setState(() => _editableFields['medical_elsewhere'] = value!)
          : null,
    );
  }

  Widget _buildUploadButton(String label, String fieldKey) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: ElevatedButton.icon(
        onPressed: () => _pickAndUpload(fieldKey),
        icon: const Icon(Icons.upload),
        label: Text('Upload $label'),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.orangeAccent,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          elevation: 4,
          padding: const EdgeInsets.symmetric(vertical: 12),
        ),
      ),
    );
  }
}
