import 'package:flutter/foundation.dart';
import '../models/employee.dart';

class AuthService with ChangeNotifier {
  Employee? _user;
  bool _isLoggedIn = false;

  Employee? get user => _user;
  bool get isLoggedIn => _isLoggedIn;

  void login(Employee user) {
    _user = user;
    _isLoggedIn = true;
    notifyListeners();
  }

  void logout() {
    _user = null;
    _isLoggedIn = false;
    notifyListeners();
  }
}