import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/dependent.dart';

class ApiService {
  static const String baseUrl = 'http://10.145.219.182/api1'; // ← CHANGE THIS

  static Future<Map<String, dynamic>> login(int employeeId, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'employee_id': employeeId, 'password': password}),
    );
    return jsonDecode(response.body);
  }

  static Future<List<Dependent>> getDependents(int employeeId) async {
    final response = await http.get(Uri.parse('$baseUrl/get_dependants.php?employee_id=$employeeId'));
    final data = jsonDecode(response.body);
    if (data['success']) {
      return (data['dependents'] as List)
          .map((d) => Dependent.fromJson(d))
          .toList();
    } else {
      throw Exception(data['message']);
    }
  }

  static Future<Map<String, dynamic>> updateDependent(int id, Map<String, dynamic> fields) async {
    final response = await http.post(
      Uri.parse('$baseUrl/update_dependant.php'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'id': id, ...fields}),
    );
    return jsonDecode(response.body);
  }

  static Future<Map<String, dynamic>> uploadFile(int dependentId, String fieldKey, String filePath) async {
    final request = http.MultipartRequest('POST', Uri.parse('$baseUrl/upload.php'));
    request.files.add(await http.MultipartFile.fromPath('file', filePath));
    request.fields['dependent_id'] = dependentId.toString();
    request.fields['field'] = fieldKey;

    final response = await request.send();
    final respStr = await response.stream.bytesToString();
    return jsonDecode(respStr);
  }
}