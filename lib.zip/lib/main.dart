import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'services/auth_service.dart';
import 'screens/login_screen.dart';
import 'screens/dependents_screen.dart';

void main() {
  runApp(ChangeNotifierProvider(
    create: (_) => AuthService(),
    child: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Employee Dependents',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: AuthWrapper(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);

    // Show login if not authenticated, else show main app
    return auth.isLoggedIn ? DependentsScreen() : LoginScreen();
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Employee Portal'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Login'),
              Tab(text: 'Dependents'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            LoginScreen(),
            auth.isLoggedIn ? DependentsScreen() : Center(child: Text('Please log in first')),
          ],
        ),
      ),
    );
  }
}